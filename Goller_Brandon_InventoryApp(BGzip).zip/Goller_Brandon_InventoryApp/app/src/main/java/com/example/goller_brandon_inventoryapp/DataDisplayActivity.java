package com.example.goller_brandon_inventoryapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import android.os.Bundle;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.example.goller_brandon_inventoryapp.InventoryAdapter;

import java.util.ArrayList;
import java.util.List;

public class DataDisplayActivity extends AppCompatActivity {

    private TextView textViewName;
    private TextView textViewQuantity;
    private TextView textViewAlert1;
    private TextView textViewAlert2;
    private RecyclerView recyclerViewInventory;
    private InventoryAdapter inventoryAdapter;
    private List<InventoryItem> inventoryItems;
    private String itemDescription;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize RecyclerView and adapter
        recyclerViewInventory = findViewById(R.id.recyclerViewInventory);
        inventoryAdapter = new InventoryAdapter(this);

        // Set RecyclerView's layout manager and adapter
        recyclerViewInventory.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewInventory.setAdapter(inventoryAdapter);

        // Fetch inventory data from the database (replace this with your database query)
        List<InventoryItem> inventoryItems = fetchInventoryItemsFromDatabase();
        inventoryAdapter.setInventoryItems(inventoryItems);
    }
    public void setInventoryItems(List<InventoryItem> inventoryItems) {
        this.inventoryItems = inventoryItems;
        inventoryAdapter.notifyDataSetChanged();
    }

    private List<InventoryItem> fetchInventoryItemsFromDatabase() {
        // Replace this with your actual database query to fetch inventory items
        List<InventoryItem> inventoryItems = new ArrayList<>();
        inventoryItems.add(new InventoryItem("Item 1", 10, itemDescription));
        inventoryItems.add(new InventoryItem("Item 2", 20, itemDescription));
        inventoryItems.add(new InventoryItem("Item 3", 30, itemDescription));
        return inventoryItems;
    }
}
