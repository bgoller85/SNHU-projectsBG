package com.example.goller_brandon_inventoryapp;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SignupActivity extends AppCompatActivity {

    private EditText editTextUsername;
    private EditText editTextPassword;
    private Button buttonCreateAccount;

    private SQLiteDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        // Initialize UI components
        editTextUsername = findViewById(R.id.editTextUsername);
        editTextPassword = findViewById(R.id.editTextPassword);
        buttonCreateAccount = findViewById(R.id.buttonCreateAccount);

        // Initialize database
        InventoryDatabaseHelper databaseHelper = new InventoryDatabaseHelper(this);
        database = databaseHelper.getWritableDatabase();

        buttonCreateAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get username and password from EditText fields
                String username = editTextUsername.getText().toString().trim();
                String password = editTextPassword.getText().toString().trim();

                // Check if username and password are not empty
                if (!username.isEmpty() && !password.isEmpty()) {
                    // Create ContentValues object with username and password
                    ContentValues values = new ContentValues();
                    values.put("username", username);
                    values.put("password", password);

                    // Insert data into the database
                    long result = database.insert("users", null, values);

                    // Check if data was inserted successfully
                    if (result != -1) {
                        // Data inserted successfully
                        Toast.makeText(SignupActivity.this, "Account created successfully", Toast.LENGTH_SHORT).show();
                        finish(); // Finish the activity
                    } else {
                        // Data insertion failed
                        Toast.makeText(SignupActivity.this, "Error creating account", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    // Username or password is empty
                    Toast.makeText(SignupActivity.this, "Please enter a username and password", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        // Close the database connection
        if (database != null) {
            database.close();
        }
    }
}

