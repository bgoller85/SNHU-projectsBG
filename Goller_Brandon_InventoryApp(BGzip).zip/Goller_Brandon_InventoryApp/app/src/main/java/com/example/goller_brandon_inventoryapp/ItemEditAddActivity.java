package com.example.goller_brandon_inventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ItemEditAddActivity extends AppCompatActivity {

    // EditText fields for item details
    private EditText editTextItemName;
    private EditText editTextItemQuantity;
    private EditText editTextItemDescription;

    // Button for adding item
    private Button buttonAddItem;

    // Button for removing item
    private Button buttonRemoveItem;

    // Button for editing item
    private Button buttonEditItem;

    private InventoryDatabaseHelper inventoryDatabaseHelper;
    private int selectedItemId = -1; // Initialize with a default value

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_edit_add);

        // Initialize EditText fields
        editTextItemName = findViewById(R.id.editTextItemName);
        editTextItemQuantity = findViewById(R.id.editTextItemQuantity);
        editTextItemDescription = findViewById(R.id.editTextItemDescription);

        // Initialize buttons
        buttonAddItem = findViewById(R.id.buttonItemAdd);
        buttonRemoveItem = findViewById(R.id.buttonRemoveItem);
        buttonEditItem = findViewById(R.id.buttonEditItem);
        inventoryDatabaseHelper = new InventoryDatabaseHelper(this);

        // Set up OnClickListener for the Add Item button
        buttonAddItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the item details from the EditText fields
                String itemName = editTextItemName.getText().toString().trim();
                String itemQuantity = editTextItemQuantity.getText().toString().trim();
                String itemDescription = editTextItemDescription.getText().toString().trim();

                // Check if any of the fields are empty
                if (itemName.isEmpty() || itemQuantity.isEmpty() || itemDescription.isEmpty()) {
                    Toast.makeText(ItemEditAddActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Add the item to the database
                InventoryItem newItem = new InventoryItem(itemName, Integer.parseInt(itemQuantity), itemDescription);
                inventoryDatabaseHelper.addItem(newItem);

                // Display a toast message indicating success
                Toast.makeText(ItemEditAddActivity.this, "Item added successfully", Toast.LENGTH_SHORT).show();

                // Finish the activity
                finish();
            }
        });

        // Set up OnClickListener for the Remove Item button
        buttonRemoveItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Remove the item from the database
                inventoryDatabaseHelper.removeItem(String.valueOf(selectedItemId));

                // Display a toast message indicating success
                Toast.makeText(ItemEditAddActivity.this, "Item removed successfully", Toast.LENGTH_SHORT).show();

                // Finish the activity
                finish();
            }
        });

        // Set up OnClickListener for the Edit Item button
        buttonEditItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the updated item details from the EditText fields
                String itemName = editTextItemName.getText().toString().trim();
                String itemQuantity = editTextItemQuantity.getText().toString().trim();
                String itemDescription = editTextItemDescription.getText().toString().trim();

                // Check if any of the fields are empty
                if (itemName.isEmpty() || itemQuantity.isEmpty() || itemDescription.isEmpty()) {
                    Toast.makeText(ItemEditAddActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Update the item in the database
                InventoryItem updatedItem = new InventoryItem(itemName, Integer.parseInt(itemQuantity), itemDescription);
                inventoryDatabaseHelper.updateItem(updatedItem);

                // Display a toast message indicating success
                Toast.makeText(ItemEditAddActivity.this, "Item updated successfully", Toast.LENGTH_SHORT).show();

                // Finish the activity
                finish();
            }
        });

        // Initialize the item details if editing an existing item
        Intent intent = getIntent();
        if (intent.hasExtra("editMode")) {
            // Get the item details from the intent
            String itemName = intent.getStringExtra("itemName");
            int itemQuantity = intent.getIntExtra("itemQuantity", 0);
            String itemDescription = intent.getStringExtra("itemDescription");

            // Set the item details in the EditText fields
            editTextItemName.setText(itemName);
            editTextItemQuantity.setText(String.valueOf(itemQuantity));
            editTextItemDescription.setText(itemDescription);

            // Change the text of the Add Item button to "Save Changes"
            buttonAddItem.setText("Save Changes");
        }
    }
}
